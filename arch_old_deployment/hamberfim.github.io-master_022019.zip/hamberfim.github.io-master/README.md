# hamberfim.github.io

### Sempre imparando, Sempre giocando:

[html-css Prototype Proposal](https://hamberfim.github.io/Kate_Isaacs/)

[Graphic design, mobile design & information architecture](https://hamberfim.github.io/Alcune_Opere_Grafiche/)

[Vue.js/Vuetify.js testing](https://hamberfim.gitlab.io/vuetify_alpha/)

[Github Webpage](https://hamberfim.github.io/)

[CSS Grid Experiment-Basic Hero](https://hamberfim.github.io/Simple_Web_Grid_Layouts/simple_hero/simple_hero.html)

[CSS Grid Experiment-wrap N stack](https://hamberfim.github.io/Simple_Web_Grid_Layouts/wrap_n_stack/index.html)

[CSS Grid Experiment-8 column](https://hamberfim.github.io/Simple_Web_Grid_Layouts/cust_materialize/index.html)

[CSS Grid Experiment-old school top nav](https://hamberfim.github.io/Simple_Web_Grid_Layouts/simple_hortz/index_hrzNav.html)

[CSS Grid Experiment-old school side nav](https://hamberfim.github.io/Simple_Web_Grid_Layouts/simple_sidebar/index_sbNav.html)
